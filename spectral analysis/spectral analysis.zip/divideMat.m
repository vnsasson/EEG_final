function [deltaMat,thetaMat,alphaMat,betaMat,gammaMat] = divideMat(Mat)
% divide the whole subject matrix (Mat) to
% 5 matrixes - each for wave region (delta,theta,..)

    brainRegionNum = 7;
    patientNum = 13;

    deltaMat = zeros(patientNum,brainRegionNum*2);
    thetaMat = zeros(patientNum,brainRegionNum*2);
    alphaMat = zeros(patientNum,brainRegionNum*2);
    betaMat  = zeros(patientNum,brainRegionNum*2);
    gammaMat = zeros(patientNum,brainRegionNum*2);
    
    % insert first table
    deltaMat(1,:) = Mat(1,:);
    thetaMat(1,:) = Mat(2,:);
    alphaMat(1,:) = Mat(3,:);
    betaMat(1,:)  = Mat(4,:);
    gammaMat(1,:) = Mat(5,:);  
    
    
    for i = 1 : patientNum - 1
        deltaMat(i+1,:) = Mat((i*brainRegionNum),:);
        thetaMat(i+1,:) = Mat((i*brainRegionNum)+1,:);
        alphaMat(i+1,:) = Mat((i*brainRegionNum)+2,:);
        betaMat(i+1,:)  = Mat((i*brainRegionNum)+3,:);
        gammaMat(i+1,:) = Mat((i*brainRegionNum)+4,:);
    end
    
end
    

        
