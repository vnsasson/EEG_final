
function [Mat,count1,count2] = spectral_analysis_func(ALLEEG,filename,filepath,Mat,k,count1,count2)

fs = 500;

EEG = pop_loadset('filename',filename,'filepath',filepath);

 %% calculate PSD using Welch
 
 mat_dim = size(EEG.data); % (number of electrodes,data length)
 Num_elec = mat_dim(1); % number of electrodes
 
 Psd_length = length(pwelch(EEG.data(1,:),fs)); % length of PSD
 
 PSD_Mat = zeros(Num_elec,Psd_length); % produce empty matrix
 
 
%figure;
 
 for i = 1:Num_elec
       
    [Psd,theta] = pwelch(EEG.data(i,:),fs);
    f = (theta*fs)/(2*pi);
    PSD_Mat(i,:) = Psd';
    PSD_Mat(i,:) = log10(PSD_Mat(i,:));
 
%     plot(f,PSD_Mat(i,:));
%     xlim([0 45]);
%     title('Power Spectral Density');
%     xlabel('Frequency [Hz]');
%     ylabel('Amplitude ( log_{10} )');
%     hold on
  
 end
 
 %hold off

 
 %% calculate wave values for each patient: 
 % 1-delta (0.5-3.5 Hz), 2-theta (3.5-7.4 Hz), 3-alpha (7.4-12.4 Hz),
 % 4-beta (12.4-30 Hz), 5-gamma (30-45 Hz)
 
 freq_regions = 5;
  
 Wave_Mat = zeros(Num_elec,freq_regions); 

 % calculate PSD integral for each wave range for each electrode
 for i = 1:Num_elec 
     
     Wave_Mat(i,1) = sum(PSD_Mat(i,find(f<3.5))) - sum(PSD_Mat(i,find(f<0.5)));
     Wave_Mat(i,2) = sum(PSD_Mat(i,find(f<7.4))) - sum(PSD_Mat(i,find(f<3.6)));
     Wave_Mat(i,3) = sum(PSD_Mat(i,find(f<12.4))) - sum(PSD_Mat(i,find(f<7.4)));
     Wave_Mat(i,4) = sum(PSD_Mat(i,find(f<30))) - sum(PSD_Mat(i,find(f<12.4)));
     Wave_Mat(i,5) = sum(PSD_Mat(i,find(f<45))) - sum(PSD_Mat(i,find(f<30)));

end
 

%% transform to number labeling for each area

[frontal,central,post_occ,left,right,broca,wernick] = fill_regions(Num_elec);

%% calculate the values for this subject

if (strfind(filename,'screen') > 0) % screen dataseet
    Mat = fill_T_screen(Mat,Wave_Mat,k,frontal,central,post_occ,left,right,broca,wernick);
    count1 = count1+1;
elseif (strfind(filename,'paper') > 0) % paper dataset    
    Mat = fill_T_paper(Mat,Wave_Mat,k,frontal,central,post_occ,left,right,broca,wernick);
    count2 = count2+1;
end

