clc; close all; clear all;

[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;  

count1 = 0;
count2 = 0;

% import set from this dir
setDir = 'C:\\Users\\sasso\\Desktop\\Studies\\Project\\B- Brain activity during reading\\datasets\\After'; 

myFiles = dir(fullfile(setDir,'*.set')); % gets all .set files in struct

freqReg = 5; % alpha, beta,... (number of frequency regions)
brainReg = 7; % frontal, left, right,... (number of brain regions)
filesNum = size(myFiles);
filesNum = filesNum(1);

Mat = zeros(freqReg*filesNum,brainReg*2);

for k = 1:length(myFiles)
  filename = myFiles(k).name;
  filepath = myFiles(k).folder;
  [Mat,count1,count2] = spectral_analysis_func(ALLEEG,filename,filepath,Mat,k,count1,count2);   
end

%% divide the big mat to 5 wave matrixes and reorganize

[deltaMat,thetaMat,alphaMat,betaMat,gammaMat] = divideMat(Mat);


[deltaMat,thetaMat,alphaMat,betaMat,gammaMat] = reorganizeMat(deltaMat,thetaMat,alphaMat,betaMat,gammaMat);


%%  export the matrixes

writematrix(deltaMat,'C:\Users\sasso\Desktop\Studies\Project\B- Brain activity during reading\eeglab2020_0\excel_mat\deltaMat.xlsx');
writematrix(thetaMat,'C:\Users\sasso\Desktop\Studies\Project\B- Brain activity during reading\eeglab2020_0\excel_mat\thetaMat.xlsx');
writematrix(alphaMat,'C:\Users\sasso\Desktop\Studies\Project\B- Brain activity during reading\eeglab2020_0\excel_mat\alphaMat.xlsx');
writematrix(betaMat,'C:\Users\sasso\Desktop\Studies\Project\B- Brain activity during reading\eeglab2020_0\excel_mat\betaMat.xlsx');
writematrix(gammaMat,'C:\Users\sasso\Desktop\Studies\Project\B- Brain activity during reading\eeglab2020_0\excel_mat\gammaMat.xlsx');




